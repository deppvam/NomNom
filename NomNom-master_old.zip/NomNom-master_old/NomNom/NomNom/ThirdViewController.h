//
//  ThirdViewController.h
//  NomNom
//
//  Created by TIMGO001 on 4/24/18.
//  Copyright © 2018 Joanna Wang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController
- (IBAction)logout:(id)sender;

@end
