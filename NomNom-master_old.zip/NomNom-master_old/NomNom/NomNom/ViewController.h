//
//  ViewController.h
//  NomNom
//
//  Created by Joanna Wang on 4/20/18.
//  Copyright © 2018 Joanna Wang. All rights reserved.
//

#import <UIKit/UIKit.h>
#include <stdlib.h>

@interface ViewController : UIViewController


@end

